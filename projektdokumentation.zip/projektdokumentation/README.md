# WedO Projektdokumentation

Dieser Ordner enthaelt die Unterlagen fuer die Uni-Abgabe und die Abschlusspräsentation.

## Dateien

- `ABGABE_Projektdokumentation_WedO.md` - kurze Projektdokumentation fuer das PDF, auf maximal 3 A4-Seiten ausgelegt.
- `PRAESENTATION_Konzept_und_Ausarbeitung_WedO.md` - ausfuehrliche Grundlage fuer eine ca. 15-minuetige Abschlusspräsentation.

## PDF-Export

Die Abgabedatei sollte als PDF exportiert werden. Geeignete Wege:

- In VS Code: Markdown Preview oeffnen und mit Browser/Print-to-PDF exportieren.
- Mit Pandoc, falls installiert:

```bash
pandoc ABGABE_Projektdokumentation_WedO.md -o ABGABE_Projektdokumentation_WedO.pdf
```

Beim Export auf A4 achten und pruefen, dass die PDF maximal 3 Seiten hat.
