# WedO - Ausfuehrliche Projektgrundlage fuer die Abschlusspräsentation

Diese Datei dient als Materialsammlung fuer eine ca. 15-minuetige Abschlusspräsentation. Sie enthaelt Kommunikationskonzept, Zielgruppen, Personas, Use Cases, User Journeys, Requirements, Architektur, Demo-Ablauf, Learnings und moegliche Folienstruktur.

## 1. Elevator Pitch

WedO ist eine mobile Hochzeitsfoto-App, mit der Gaeste Fotos per QR-Code direkt in eine gemeinsame Event-Galerie hochladen koennen. Fotografen erstellen Events, teilen den QR-Code mit den Gaesten und verwalten die gesammelten Bilder zentral. Die App verbindet einfache Gast-Nutzung ohne Login mit einem geschuetzten Fotografenbereich.

## 2. Problemstellung

Bei Hochzeiten entstehen viele authentische Fotos auf den Smartphones der Gaeste. Diese Bilder landen spaeter oft verstreut in WhatsApp-Gruppen, privaten Galerien oder werden gar nicht geteilt. Fuer Brautpaar und Fotograf ist es schwierig, alle Perspektiven des Tages gesammelt zu bekommen.

WedO soll diesen Prozess vereinfachen:

- Gaeste sollen ohne Account schnell teilnehmen koennen.
- Der Einstieg soll ueber QR-Code funktionieren.
- Alle Bilder sollen pro Hochzeit gesammelt werden.
- Fotografen sollen Events und Bilder verwalten koennen.
- Teilen soll ueber native Smartphone-Funktionen moeglich sein.

## 3. Zielgruppe

### Primaere Zielgruppen

**Hochzeitsfotografen:** Sie wollen Gaeste-Fotos zentral sammeln, ohne manuell Links, Cloud-Ordner oder Messenger-Gruppen verwalten zu muessen.

**Hochzeitsgaeste:** Sie wollen ohne komplizierte Registrierung Fotos aufnehmen und teilen.

### Sekundaere Zielgruppen

**Brautpaare:** Sie profitieren von einer groesseren Fotoauswahl und bekommen spontane Momente aus Sicht der Gaeste.

**Eventplaner:** Das Konzept laesst sich spaeter auch auf Geburtstage, Firmenfeiern oder andere Events erweitern.

## 4. Personas

### Persona 1: Sarah, Hochzeitsfotografin

- Alter: 31
- Kontext: Fotografiert regelmaessig Hochzeiten und moechte Gaeste-Fotos strukturiert sammeln.
- Ziele: Event schnell erstellen, QR-Code teilen, Galerie kontrollieren, einzelne Fotos speichern oder loeschen.
- Pain Points: Messenger-Chaos, unvollstaendige Foto-Sammlungen, viele manuelle Nachfragen.
- Erwartung an WedO: Einfacher Event-Workflow und professionelle Verwaltung.

### Persona 2: Lukas, Hochzeitsgast

- Alter: 26
- Kontext: Macht viele spontane Fotos mit dem Smartphone.
- Ziele: QR-Code scannen, Foto aufnehmen, hochladen, Galerie ansehen.
- Pain Points: Keine Lust auf Registrierung, keine komplizierte App-Erklaerung.
- Erwartung an WedO: Sofort verstehen, sofort nutzen.

### Persona 3: Anna und Markus, Brautpaar

- Alter: 29 und 32
- Kontext: Wollen moeglichst viele Erinnerungen an ihren Hochzeitstag sammeln.
- Ziele: Fotos aus verschiedenen Perspektiven erhalten.
- Pain Points: Bilder werden oft in privaten Chats vergessen.
- Erwartung an WedO: Ein zentraler Ort fuer Gaeste-Fotos.

## 5. Stakeholder und Kommunikation

### Stakeholder

- Gaeste als schnelle, nicht angemeldete Nutzer
- Fotografen als angemeldete Hauptnutzer
- Brautpaar als indirekter Auftraggeber
- Lehrveranstaltung / Pruefer als bewertende Instanz

### Kommunikationsziele der App

Die App muss ohne lange Erklaerung kommunizieren:

- "Scanne den QR-Code und lade Fotos hoch."
- "Du bist Gast und brauchst keinen Account."
- "Du bist Fotograf und verwaltest Events im Dashboard."
- "Fotos sind pro Event gesammelt."

### Tonalitaet

WedO soll freundlich, festlich und vertrauenswuerdig wirken. Die App nutzt eine klare Sprache und trennt Gast- und Fotografen-Flow deutlich. Die UI darf emotional zum Hochzeitsthema passen, soll aber nicht verspielt auf Kosten der Bedienbarkeit werden.

### Kommunikationskanaele im Produkt

- QR-Code als Einstiegspunkt fuer Gaeste
- Deep-Link `wedo://event/{weddingId}`
- Nativer Share-Dialog fuer Einladung und Fotos
- Event-Karten und Galerie als visuelle Orientierung
- Anleitungsscreen fuer Gast- und Fotografenrolle

## 6. Kernfunktionen

### Gastfunktionen

- QR-Code scannen
- Link manuell eingeben
- Event bestaetigen
- Foto aufnehmen
- Foto lokal speichern
- Foto in Firebase hochladen
- Event-Galerie ansehen
- Foto speichern oder teilen
- Zum zuletzt gescannten Event zurueckkehren

### Fotografenfunktionen

- Registrieren und einloggen
- Event erstellen
- Datum und Location erfassen
- Eventliste im Dashboard ansehen
- Event-Detailseite oeffnen
- QR-Code und Link anzeigen
- Einladung per Share-Dialog teilen
- Event bearbeiten
- Fotos ansehen, speichern, teilen und loeschen

## 7. Use Cases

### Use Case 1: Fotograf erstellt ein Event

**Akteur:** Fotograf  
**Vorbedingung:** Fotograf ist eingeloggt.  
**Ablauf:** Dashboard oeffnen, neues Event anlegen, Titel/Datum/Location eingeben, speichern.  
**Ergebnis:** Neues Dokument in `weddings`, Event erscheint im Dashboard.

### Use Case 2: Gast tritt einem Event bei

**Akteur:** Gast  
**Vorbedingung:** Fotograf hat QR-Code oder Link geteilt.  
**Ablauf:** QR-Code scannen, Eventdaten laden, Event bestaetigen.  
**Ergebnis:** Gast ist im Event-Kontext und kann Fotos aufnehmen oder Galerie ansehen.

### Use Case 3: Gast laedt Foto hoch

**Akteur:** Gast  
**Vorbedingung:** Gast befindet sich in einem Event.  
**Ablauf:** Kamera oeffnen, Foto aufnehmen, Berechtigungen bestaetigen, Upload abwarten.  
**Ergebnis:** Bild liegt in Firebase Storage, Foto-Dokument liegt in Firestore.

### Use Case 4: Fotograf verwaltet Galerie

**Akteur:** Fotograf  
**Vorbedingung:** Event existiert und Fotos wurden hochgeladen.  
**Ablauf:** Event oeffnen, Galerie ansehen, Foto previewen, speichern/teilen/loeschen.  
**Ergebnis:** Fotograf kontrolliert die Event-Fotos.

### Use Case 5: Einladung teilen

**Akteur:** Fotograf  
**Vorbedingung:** Event existiert.  
**Ablauf:** Event-Detailseite oeffnen, "Einladung teilen" antippen, Ziel-App im nativen Share-Sheet waehlen.  
**Ergebnis:** Gaeste erhalten den WedO-Link.

## 8. User Journeys

### Journey A: Gast beim Event

1. Gast sieht QR-Code auf Tischkarte, Leinwand oder Einladung.
2. Gast oeffnet WedO und scannt den Code.
3. WedO zeigt den Eventnamen, damit der Gast sicher ist, im richtigen Event zu sein.
4. Gast nimmt ein Foto auf.
5. WedO speichert das Foto lokal und laedt es in die Cloud.
6. Gast oeffnet die Galerie und sieht weitere Event-Fotos.
7. Beim spaeteren App-Start findet WedO das zuletzt genutzte Event wieder.

### Journey B: Fotograf vor der Hochzeit

1. Fotograf registriert sich oder loggt sich ein.
2. Fotograf erstellt das Hochzeits-Event.
3. App generiert Event-ID, Share-Code und QR-Code.
4. Fotograf teilt den Link mit dem Brautpaar oder druckt den QR-Code.
5. Event ist fuer Gaeste vorbereitet.

### Journey C: Fotograf waehrend/nach der Hochzeit

1. Fotograf oeffnet das Dashboard.
2. Fotograf sieht Anzahl der hochgeladenen Fotos.
3. Fotograf oeffnet Event-Details.
4. Fotograf prueft Bilder in der Galerie.
5. Fotograf teilt, speichert oder loescht einzelne Fotos.

## 9. Requirements

### Funktionale Requirements

- Nutzer koennen als Fotograf einen Account erstellen.
- Fotografen koennen sich einloggen und ausloggen.
- Fotografen koennen Events erstellen, lesen und bearbeiten.
- Fotografen koennen Event-Einladungen teilen.
- Gaeste koennen per QR-Code oder Link einem Event beitreten.
- Gaeste koennen Fotos aufnehmen und hochladen.
- Gaeste und Fotografen koennen Event-Fotos ansehen.
- Fotografen koennen Fotos loeschen.
- Fotos koennen ueber den nativen Share-Dialog geteilt werden.

### Nicht-funktionale Requirements

- Mobile-first, da Nutzung waehrend eines Events am Smartphone passiert.
- Einfache Gast-Nutzung ohne Registrierung.
- Persistente Speicherung in einer Cloud-Datenbank.
- Klare Trennung zwischen Gast- und Fotografenrolle.
- Verstaendliche UI fuer kurze Nutzungssituationen.
- TypeScript fuer stabilere Entwicklung.

### Uni-Kriterien

| Kriterium | Umsetzung |
|---|---|
| CRUD | Event erstellen/lesen/bearbeiten, Fotos erstellen/lesen/loeschen |
| Persistierende Daten | Firebase Firestore und Firebase Storage |
| Offline oder Share | Share-Dialog umgesetzt |
| Keine Web-App | Expo React Native Mobile App |
| Learnings | In Doku und Praesentation enthalten |

## 10. Informationsarchitektur

```text
Welcome
  |-- QRScanner
  |     |-- GuestCamera
  |     |-- GuestGallery
  |
  |-- Login
  |     |-- Dashboard
  |           |-- EventDetail
  |                 |-- GuestCamera
  |                 |-- PhotoPreview
  |
  |-- Instructions
```

## 11. Datenmodell

### Collection `weddings`

```text
weddings/{weddingId}
  title: string
  createdBy: string
  shareCode: string
  date?: string
  location?: string
  createdAt: Timestamp
```

### Collection `photos`

```text
photos/{photoId}
  weddingId: string
  uploadedBy: 'guest' | 'photographer'
  imageUrl: string
  storagePath: string
  localAssetId?: string | null
  createdAt: Timestamp
```

### Storage-Struktur

```text
weddings/{weddingId}/images/{timestamp}-{random}.jpg
```

## 12. Architektur

### Frontend

- React Native Screens fuer die einzelnen Workflows
- React Navigation fuer Stack-Navigation
- Wiederverwendbare Komponenten wie Button, Header, PhotoGrid, QRCodeCard und PhotoPreviewModal
- ThemeContext fuer Farben und Typografie

### Backend / Cloud

- Firebase Auth fuer Fotografen-Login
- Firestore fuer Events und Foto-Metadaten
- Firebase Storage fuer Bilddateien
- Firebase Security Rules fuer Zugriffskontrolle

### Lokale Speicherung

- AsyncStorage fuer Auth-Persistence
- AsyncStorage fuer zuletzt gescanntes Gast-Event
- Media Library fuer lokale Speicherung auf dem Geraet

## 13. Technische Entscheidungen

### Warum Mobile App?

Der Kern der App ist Kamera, QR-Code, Galeriezugriff und natives Teilen. Diese Funktionen gehoeren direkt zum Smartphone-Kontext. Eine Web-App waere fuer die Aufgabenstellung nicht erlaubt und wuerde sich fuer Kamera-/Galerieflows weniger nativ anfuehlen.

### Warum Expo React Native?

- Gemeinsame Codebasis fuer Android und iOS
- Gute Unterstuetzung fuer Kamera, Media Library und native APIs
- Schnelles Prototyping fuer ein Uni-MVP
- TypeScript-Unterstuetzung
- Gute Kombinierbarkeit mit Firebase

### Warum Firebase?

- Kein eigenes Backend noetig
- Auth, Datenbank und Storage aus einer Plattform
- Schnelle Umsetzung von persistenten Daten
- Geeignet fuer MVPs und Demo-Projekte

## 14. Mockup / Wireframe

### Startscreen

```text
+--------------------------------+
| WedO                           |
| Wedding Photo Sharing          |
|                                |
| [ QR-Code scannen ]            |
| [ Fotografen-Login ]           |
| [ Wie funktioniert's? ]        |
|                                |
| Letztes Event                  |
| [ Weiter hochladen ] [Galerie] |
+--------------------------------+
```

### Fotografen-Dashboard

```text
+--------------------------------+
| Dashboard              Logout  |
| Events this season: 3          |
| Total photos: 128              |
|                                |
| + Neues Event                  |
|                                |
| [ Anna & Markus ] 42 Fotos     |
| [ Lisa & Tom    ] 31 Fotos     |
+--------------------------------+
```

### Event-Detailseite

```text
+--------------------------------+
| Anna & Markus          Share   |
| 31.05.2026 | Wien              |
|                                |
| [ QR-Code ]                    |
| wedo://event/abc123            |
| [ Einladung teilen ]           |
|                                |
| Hochgeladene Fotos             |
| [img] [img] [img]              |
| [img] [img] [img]              |
+--------------------------------+
```

### Gast-Kamera

```text
+--------------------------------+
| Event: Anna & Markus           |
|                                |
|          Kamera-Preview        |
|                                |
| [Flash] [Ausloeser] [Switch]   |
| [ Galerie ansehen ]            |
+--------------------------------+
```

## 15. UX-Prinzipien

- Gast-Flow ohne Login, damit die Einstiegshuerde niedrig bleibt.
- QR-Code als schneller Event-Kontext.
- Event-Bestaetigung verhindert versehentliche Uploads ins falsche Event.
- Fotografenbereich ist getrennt und authentifiziert.
- Visuelle Galerie macht den Nutzen direkt sichtbar.
- Native Share-Sheets senken Reibung beim Teilen.
- Pull-to-refresh ist fuer Nutzer bekannt und passt zur Galerie.

## 16. Edge Cases und Fehlerfaelle

- Kamera- oder Galerie-Berechtigung wird verweigert.
- QR-Code enthaelt kein gueltiges WedO-Linkformat.
- Event wurde geloescht oder existiert nicht.
- Netzwerk ist beim Upload instabil.
- Storage-Delete schlaegt fehl, Firestore-Dokument wird trotzdem bereinigt.
- Gast versucht ohne Event-Kontext ein Foto hochzuladen.
- Firebase Rules wurden nicht deployed.

## 17. Demo-Ablauf fuer 15 Minuten

### 0:00-1:30 Einstieg

- Problem erklaeren: Hochzeitsfotos sind verstreut.
- Ziel der App vorstellen: gemeinsame Galerie per QR-Code.

### 1:30-3:00 App-Art und Tech Stack

- Native Mobile App mit Expo React Native.
- Firebase fuer Auth, Firestore und Storage.
- Warum keine Web-App und warum Share-Dialog.

### 3:00-6:00 Fotografen-Flow zeigen

- Login/Registrierung kurz erklaeren.
- Dashboard zeigen.
- Event erstellen.
- Event-Detailseite, QR-Code und Share-Dialog zeigen.

### 6:00-9:00 Gast-Flow zeigen

- QR-Code scannen oder Link manuell eingeben.
- Event bestaetigen.
- Foto aufnehmen.
- Upload-Status und Galerie zeigen.

### 9:00-11:00 CRUD und Datenmodell

- Create: Event und Foto.
- Read: Dashboard, Galerie, Detailseite.
- Update: Event bearbeiten.
- Delete: Foto loeschen.
- Firestore Collections und Storage-Struktur erklaeren.

### 11:00-13:00 Requirements und Learnings

- Uni-Kriterien abhaken.
- Was lief gut/schlecht.
- Was wuerden wir anders machen.

### 13:00-15:00 Fazit und Fragen

- MVP-Ziel erreicht.
- Ausblick: Offline-Queue, Moderation, Bulk-Download.
- Fragen beantworten.

## 18. Folienvorschlag

1. Titel: WedO - Wedding Photo Sharing App
2. Problem: Hochzeitsfotos sind verstreut
3. Loesung: QR-Code-basierte Event-Galerie
4. Zielgruppen und Personas
5. User Journey Gast
6. User Journey Fotograf
7. Live-Demo / Screens
8. Requirements: CRUD, persistente Daten, Share-Dialog
9. Architektur und Datenmodell
10. Framework-Entscheidung
11. Learnings
12. Fazit und Ausblick

## 19. Mögliche Sprechertexte

### Einstieg

"Unser Projekt heisst WedO. Die Idee dahinter ist einfach: Auf Hochzeiten entstehen sehr viele Fotos auf den Smartphones der Gaeste. Diese Fotos werden aber oft spaeter ueber verschiedene Chats verteilt oder gehen komplett unter. WedO sammelt diese Bilder pro Hochzeit in einer gemeinsamen Galerie."

### Framework-Begruendung

"Wir haben uns fuer eine mobile App mit Expo React Native entschieden, weil unser Haupt-Use-Case direkt auf dem Smartphone passiert: QR-Code scannen, Kamera nutzen, Fotos lokal speichern und Inhalte ueber den nativen Share-Dialog teilen. Firebase ergaenzt das gut, weil wir damit Authentifizierung, Datenbank und Bildspeicher ohne eigenes Backend umsetzen konnten."

### Requirements

"Die drei geforderten Kriterien sind umgesetzt. CRUD ist ueber Events und Fotos abgedeckt. Die Daten werden persistent in Firestore und Firebase Storage gespeichert. Als Zusatzkriterium haben wir den Share-Dialog gewaehlt, sowohl fuer Event-Einladungen als auch fuer einzelne Fotos."

### Learnings

"Gut funktioniert hat die Kombination aus Expo und Firebase, weil wir schnell einen echten MVP bauen konnten. Schwieriger waren native Berechtigungen, Firebase Rules und Loeschvorgaenge im Storage. Beim naechsten Mal wuerden wir frueher ein Security-Konzept und Tests fuer die wichtigsten Services einplanen."

## 20. Risiken und Verbesserungen

### Aktuelle Limitierungen

- Keine echte Offline-Upload-Queue
- Kein Bulk-Download aller Fotos
- Keine Moderation vor der Sichtbarkeit fuer Gaeste
- Keine Rollenverwaltung fuer Brautpaar oder mehrere Fotografen
- Pull-to-refresh statt Live-Updates

### Erweiterungsideen

- Offline-Warteschlange fuer Uploads
- Moderationsmodus fuer Fotografen
- ZIP-/Bulk-Export
- Album-Ansichten nach Zeitpunkt oder Gast
- Push Notifications bei neuen Bildern
- Web-Admin nur als spaetere Ergaenzung, nicht fuer diese Abgabe
- Designbare QR-Code-Karten fuer Tischaufsteller

## 21. Projektfazit

WedO ist ein realistischer MVP fuer ein konkretes Event-Problem. Die App zeigt, wie mobile Geraetefunktionen und Cloud-Datenhaltung zusammenspielen: QR-Code, Kamera, Galerie, Share-Dialog, Authentifizierung, Firestore und Storage. Fuer die Uni-Anforderungen ist das Projekt passend, weil alle Muss-Kriterien praktisch sichtbar sind und in einer Demo nachvollziehbar gezeigt werden koennen.
