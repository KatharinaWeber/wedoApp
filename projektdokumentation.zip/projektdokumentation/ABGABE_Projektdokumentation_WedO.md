# Projektdokumentation: WedO

**Projekt:** WedO - Wedding Photo Sharing App  
**App-Art:** Native Mobile App fuer Android/iOS mit Expo React Native  
**Frameworks/Technologien:** React Native, Expo, TypeScript, Firebase Auth, Firestore, Firebase Storage  
**Abgabe:** Projektdokumentation als PDF, maximal 3 A4-Seiten  

## 1. Vorstellung der App

WedO ist eine mobile App, mit der Hochzeitsgaeste ihre Fotos unkompliziert mit dem Hochzeitsteam bzw. dem Fotografen teilen koennen. Der Fotograf erstellt in der App ein Event, teilt einen QR-Code oder einen Deep-Link mit den Gaesten und verwaltet danach alle hochgeladenen Fotos in einer gemeinsamen Galerie.

Die App loest ein typisches Problem bei Hochzeiten: Fotos entstehen auf vielen privaten Smartphones, werden aber spaeter oft nur teilweise oder ueber verschiedene Messenger geteilt. WedO buendelt diese Fotos pro Event an einem Ort. Gaeste benoetigen keinen Account, sondern scannen den QR-Code, bestaetigen das Event und koennen sofort Fotos aufnehmen oder die Event-Galerie ansehen. Fotografen registrieren sich mit E-Mail und Passwort, erstellen Events und verwalten die hochgeladenen Inhalte.

## 2. Requirements und Umsetzung

### CRUD-Operationen

Die geforderten CRUD-Operationen sind in der App umgesetzt:

| Operation | Umsetzung in WedO |
|---|---|
| Create | Fotograf erstellt ein Hochzeits-Event; Gast oder Fotograf laedt ein Foto hoch. |
| Read | Events, Event-Details und Fotos werden aus Firestore gelesen und in Dashboard, Detailseite und Galerie angezeigt. |
| Update | Fotograf kann Event-Daten wie Titel, Datum und Location bearbeiten. |
| Delete | Fotograf kann Fotos aus der Galerie loeschen; dabei werden Firestore-Dokument und Storage-Datei entfernt bzw. bereinigt. |

### Persistierende Daten

WedO nutzt Firebase als persistierende Datenbasis. Firestore speichert strukturierte Daten, Firebase Storage speichert die Bilddateien. Firebase Auth verwaltet die Fotografen-Accounts. Zusaetzlich wird lokal per AsyncStorage das zuletzt gescannte Event gespeichert, damit Gaeste beim naechsten App-Start schneller zurueckkehren koennen.

**Datenmodell:**

| Collection / Speicherort | Inhalt |
|---|---|
| `weddings` | Event-Titel, Ersteller, Share-Code, Datum, Location, Erstellzeitpunkt |
| `photos` | Event-ID, Bild-URL, Storage-Pfad, Upload-Rolle, Erstellzeitpunkt |
| Firebase Storage | Bilddateien unter `weddings/{weddingId}/images/...jpg` |

### Auswahlkriterium: Share-Dialog

Als drittes Kriterium wurde der Share-Dialog umgesetzt. Fotografen koennen die Einladung zum Event ueber den nativen Share-Dialog des Smartphones teilen. Auch einzelne Fotos koennen aus der Galerie heraus geteilt werden. Dadurch fuehlt sich die App wie eine echte mobile Anwendung an und nutzt die nativen Funktionen des Betriebssystems.

## 3. Begruendung der App-Art und des Frameworks

WedO wurde bewusst als Mobile App und nicht als Web-App umgesetzt, weil der zentrale Use Case direkt auf dem Smartphone stattfindet: Gaeste fotografieren waehrend einer Hochzeit, scannen QR-Codes, speichern Bilder in der lokalen Galerie und teilen Inhalte ueber native Smartphone-Funktionen. Diese Anforderungen passen besonders gut zu einer nativen bzw. cross-platform mobilen App.

React Native mit Expo wurde gewaehlt, weil damit eine App fuer Android und iOS mit einer gemeinsamen Codebasis entwickelt werden kann. Expo vereinfacht typische Mobile-Funktionen wie Kamera, Media Library, Haptics, Clipboard und QR-Code-Flows. TypeScript sorgt fuer klarere Datenstrukturen und weniger Fehler bei Services, Navigation und Komponenten. Firebase passt gut zum MVP, weil Authentifizierung, Datenbank und Dateispeicher ohne eigenes Backend bereitgestellt werden.

## 4. Mockup und Funktionsweise

```text
Start
  |-- QR-Code scannen (Gast)
  |     |-- Event bestaetigen
  |     |-- Foto aufnehmen
  |     |-- Foto hochladen
  |     |-- Event-Galerie ansehen
  |
  |-- Fotografen-Login
        |-- Dashboard
        |-- Event erstellen
        |-- Event-Detailseite
              |-- QR-Code / Link teilen
              |-- Fotos ansehen
              |-- Event bearbeiten
              |-- Fotos speichern, teilen oder loeschen
```

**Startscreen:** Der Nutzer entscheidet zwischen Gast-Flow und Fotografen-Login. Wenn ein Gast bereits ein Event gescannt hat, wird dieses Event erneut angeboten.  
**QR-Scanner:** Gaeste scannen den Event-Code oder geben einen Link manuell ein. Danach wird das Event geladen und bestaetigt.  
**Gast-Kamera:** Die App fragt Kamera- und Galerie-Berechtigungen an, nimmt Fotos auf, speichert sie lokal und laedt sie in Firebase hoch.  
**Dashboard:** Fotografen sehen ihre Events, legen neue Hochzeiten an und oeffnen die Detailansicht.  
**Event-Detailseite:** Der Fotograf sieht QR-Code, Share-Link und Galerie. Fotos koennen geoeffnet, gespeichert, geteilt oder geloescht werden.

## 5. Learnings

**Was lief gut?**  
Die Kombination aus Expo und Firebase hat die Entwicklung eines funktionsfaehigen MVPs stark beschleunigt. Besonders Kamera, Galerie, QR-Code, Authentifizierung und Cloud-Speicher liessen sich gut in einzelne Services und Screens aufteilen. Auch die Rollenlogik zwischen Gast und Fotograf war fuer die Demo gut nachvollziehbar.

**Was lief schlecht?**  
Einige native Funktionen benoetigten genaue Berechtigungen und mussten auf echten Geraeten getestet werden. Firebase-Regeln und Storage-Loeschvorgaenge waren fehleranfaelliger als einfache Lese- und Schreiboperationen. Ausserdem musste darauf geachtet werden, dass UI-Platzhalter nicht wie fertige Funktionen wirken.

**Was wuerden wir beim naechsten Mal anders machen?**  
Beim naechsten Projekt wuerden wir frueher ein klares Datenmodell und Security-Konzept festlegen, Tests fuer die wichtigsten Services ergaenzen und den Upload-Prozess robuster gestalten. Sinnvoll waeren ausserdem Offline-Upload-Queue, Bulk-Download fuer Fotografen und eine Moderationsfunktion, bevor Fotos fuer alle sichtbar sind.

## 6. Fazit

WedO erfuellt die geforderten Kriterien: Die App besitzt CRUD-Funktionen, speichert Daten persistent in Firebase und nutzt den nativen Share-Dialog. Die App-Art und das Framework passen zum Anwendungsfall, da Hochzeitsfotos direkt mobil aufgenommen, gespeichert und geteilt werden. Das Projekt zeigt einen realistischen MVP fuer eine Event-basierte Foto-Sharing-App.
